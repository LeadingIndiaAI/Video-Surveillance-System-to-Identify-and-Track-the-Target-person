pip install --user easydict
pip install --user tqdm
pip install --user opencv-python
pip install --user h5py

luarocks install hdf5
