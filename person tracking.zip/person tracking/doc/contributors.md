Alpha Pose is contributed and maintained by Hao-Shu Fang, Jiefeng Li, Yuliang Xiu, Ruiheng Chang and Cewu Lu.
